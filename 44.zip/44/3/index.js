// Create the student object
let student = {
    name: "Alice",
    grade: 85,
    subjects: ["Math", "Science", "English"],
    displayInfo: function() {
        console.log(`Name: ${this.name}`);
        console.log(`Grade: ${this.grade}`);
        console.log(`Subjects: ${this.subjects.join(", ")}`);
    }
};

// Dynamically add 'passed' property based on grade
student.passed = student.grade >= 50; // true if grade >= 50, else false

// Display student info
student.displayInfo();

// Loop to log all keys and values of the student object
console.log("All properties:");
for (let key in student) {
    // If the value is a function, indicate it's a method
    if (typeof student[key] === 'function') {
        console.log(`${key}: [Function]`);
    } else {
        console.log(`${key}: ${student[key]}`);
    }
}
